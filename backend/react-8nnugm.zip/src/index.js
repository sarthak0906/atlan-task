import React, { Component } from 'react';
import { render } from 'react-dom';
import Hello from './Hello';
import './style.css';

const App = (props) => {
  const [file, setFile] = React.useState(null);

  React.useEffect(() => {
    console.log(file);
  }, [file]);
  
  const fileChange = (event) => {
    console.log(event.target.files[0])
    console.log(event.target.files);
    setFile(event.target.files[0])
  }

  return (
    <div>
      <Hello name={"this.state.name"} />
      <p>
        Start editing to see some magic happen :)
      </p>
      <input type="file" onChange={fileChange} />
    </div>
  );
}

render(<App />, document.getElementById('root'));